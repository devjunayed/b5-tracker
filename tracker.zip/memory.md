# Memory
<!-- What have been completed -->
<!-- which file is currently been worked  -->

 <!-- !important update the file regularly -->