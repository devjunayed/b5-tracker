# Architecture
<!-- app flow and architecture -->
<!-- folders and files structure -->
<!-- tech stack -->