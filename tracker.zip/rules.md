# Rules
<!-- What to use -->
<!-- What to avoid -->
<!-- !important Means Libraries, error handling, boundaries for AI -->
 <!-- !important update the file regularly -->