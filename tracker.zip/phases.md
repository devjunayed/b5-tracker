# Phases
<!-- Break project into phases -->
<!-- 
    Ex:
    Phase 1: Login (Completed)
    Phase 2: Dashboard (Working on)

 -->
 <!-- !important update the file regularly -->